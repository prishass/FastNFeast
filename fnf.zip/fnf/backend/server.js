// Import required modules
const express = require('express');
const mysql = require('mysql');
const bodyParser = require('body-parser');
const cors = require('cors');

// Create an express app
const app = express();
const port = 3000;

// Middleware to parse incoming request bodies
app.use(bodyParser.json());
app.use(cors());  // Enable Cross-Origin Resource Sharing

// Connect to the MySQL database
const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',  // Your MySQL username
  password: '',  // Your MySQL password
  database: 'fastnfeast'  // Your MySQL database name
});

// Connect to MySQL
db.connect((err) => {
  if (err) {
    console.error('Database connection failed: ' + err.stack);
    return;
  }
  console.log('Connected to MySQL database');
});

// Example route to test server
app.get('/', (req, res) => {
  res.send('Hello World from Fast n Feast backend!');
});

// Start server
app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});

// User Registration Route
app.post('/register', (req, res) => {
  const { email, password } = req.body;

  // SQL query to insert user details into the "users" table
  const query = `INSERT INTO users (email, password) VALUES (?, ?)`;
  
  db.query(query, [email, password], (err, results) => {
    if (err) {
      console.error('Error inserting user:', err);
      return res.status(500).json({ error: 'Failed to register user' });
    }
    res.json({ success: true, message: 'User registered successfully!' });
  });
});
