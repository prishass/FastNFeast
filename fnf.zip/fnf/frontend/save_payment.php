<?php
$host = "localhost";
$user = "root";
$pass = "";
$dbname = "fastnfeast";

// Create connection
$conn = new mysqli($host, $user, $pass, $dbname);
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// Read JSON input
$data = json_decode(file_get_contents("php://input"), true);

$items = json_encode($data["items"]);
$amount = $data["amount"];
$orderDate = $data["date"];

// Save order
$sql = "INSERT INTO orders (items, amount, order_date) VALUES ('$items', '$amount', '$orderDate')";
if ($conn->query($sql) === TRUE) {
  echo "Order saved successfully";
} else {
  echo "Error: " . $conn->error;
}

$conn->close();
?>
