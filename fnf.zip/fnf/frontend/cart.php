<!DOCTYPE html>
<html ng-app="fastnFeastApp">
<head>
  <meta charset="UTF-8">
  <title>Your Cart - Fast n Feast</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />
  <script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.8.2/angular.min.js"></script>
  <style>
    body {
      background: url('https://images.unsplash.com/photo-1540189549336-e6e99c3679fe') no-repeat center center fixed;
      background-size: cover;
      margin: 0;
      font-family: 'Segoe UI', sans-serif;
      color: white;
    }

    .overlay {
      background-color: rgba(0, 0, 0, 0.85);
      min-height: 100vh;
      padding: 30px;
    }

    h1 {
      text-align: center;
      color: #ffa726;
      font-size: 36px;
    }

    .cart-items {
      margin: 30px auto;
      max-width: 700px;
      background-color: #1e1e1e;
      padding: 25px;
      border-radius: 12px;
      box-shadow: 0 0 12px rgba(0,0,0,0.6);
    }

    .cart-item {
      display: flex;
      justify-content: space-between;
      align-items: center;
      border-bottom: 1px solid #444;
      padding: 15px 0;
    }

    .cart-item:last-child {
      border-bottom: none;
    }

    .cart-item-left {
      display: flex;
      align-items: center;
      gap: 15px;
    }

    .cart-item-name {
      font-size: 18px;
      color: #ffc107;
    }

    .cart-item-price {
      color: #ddd;
      font-size: 16px;
    }

    .cart-item-image {
      height: 60px;
      width: 60px;
      object-fit: cover;
      border-radius: 6px;
    }

    .remove-btn {
      background: none;
      border: none;
      color: #f44336;
      cursor: pointer;
      font-size: 18px;
    }

    .total-amount {
      text-align: right;
      font-size: 22px;
      font-weight: bold;
      margin-top: 20px;
      color: #4caf50;
    }

    .back-btn {
      display: block;
      margin: 30px auto;
      background-color: #ff5722;
      color: white;
      padding: 12px 24px;
      text-align: center;
      text-decoration: none;
      border-radius: 6px;
      width: fit-content;
    }

    .back-btn:hover {
      background-color: #e64a19;
    }

    @media screen and (max-width: 600px) {
      .cart-item {
        flex-direction: column;
        align-items: flex-start;
      }

      .cart-item-left {
        flex-direction: column;
        align-items: flex-start;
      }

      .cart-item-price, .remove-btn {
        margin-top: 8px;
      }
    }

    .payment-container {
      display: flex;
      justify-content: center;
      margin-top: 40px;
    }

    .payment-wrapper {
      background-color: #121212;
      padding: 30px;
      border-radius: 16px;
      box-shadow: 0 0 20px rgba(255, 165, 0, 0.4);
      width: 100%;
      max-width: 500px;
      transition: all 0.3s ease-in-out;
    }

    .payment-method h2 {
      color: #ffa726;
      margin-bottom: 20px;
      font-size: 24px;
      text-align: center;
    }

    .place-order-btn {
      background-color: #4caf50;
      color: white;
      padding: 12px 25px;
      border: none;
      border-radius: 8px;
      font-size: 16px;
      cursor: pointer;
      transition: background-color 0.3s ease;
      width: 100%;
      margin-bottom: 15px;
    }

    .place-order-btn:hover {
      background-color: #43a047;
    }

    .place-order-btn.blue {
      background-color: #2196f3;
    }

    .place-order-btn.blue:hover {
      background-color: #1976d2;
    }

  </style>
</head>
<body ng-controller="CartController">
  <div class="overlay">
    <h1><i class="fas fa-shopping-cart"></i> Your Cart</h1>

    <div class="cart-items" ng-if="cart.length > 0">
      <div class="cart-item" ng-repeat="item in cart track by $index">
        <div class="cart-item-left">
          <img class="cart-item-image" ng-src="{{ item.image }}" alt="{{ item.name }}">
          <div>
            <div class="cart-item-name">{{ item.name }}</div>
            <div class="cart-item-price">₹{{ item.price }}</div>
          </div>
        </div>
        <button class="remove-btn" ng-click="removeItem($index)">
          <i class="fas fa-trash-alt"></i>
        </button>
      </div>

      <div class="total-amount">
        <i class="fas fa-wallet"></i> Total: ₹{{ getTotalAmount() }}
      </div>
    </div>

    <div ng-if="cart.length > 0" class="payment-container">
      <div class="payment-wrapper">
        <div class="payment-method">
          <h2><i class="fas fa-credit-card"></i> Choose Payment Method</h2>
          <button class="place-order-btn" ng-click="placeCodOrder()">
            <i class="fas fa-money-bill-wave"></i> Cash on Delivery
          </button>
          <button class="place-order-btn blue" ng-click="placeOnlineOrder()">
            <i class="fas fa-globe"></i> Pay Online
          </button>
        </div>
      </div>
    </div>

    <div class="cart-items" ng-if="cart.length === 0">
      <p style="text-align: center; color: #bbb;">Your cart is empty.</p>
    </div>

    <a class="back-btn" href="index.php"><i class="fas fa-arrow-left"></i> Back to Home</a>
  </div>

  <script>
    var app = angular.module('fastnFeastApp', []);

    app.controller('CartController', function ($scope) {
      $scope.cart = JSON.parse(localStorage.getItem("cart")) || [];

      $scope.getTotalAmount = function () {
        return $scope.cart.reduce(function (total, item) {
          return total + item.price;
        }, 0);
      };

      $scope.removeItem = function (index) {
        $scope.cart.splice(index, 1);
        localStorage.setItem("cart", JSON.stringify($scope.cart));
      };

      // Payment Methods
      $scope.placeCodOrder = function () {
        if ($scope.cart.length === 0) {
          alert("Your cart is empty.");
          return;
        }

        alert("Order placed successfully!\nPayment Method: Cash on Delivery\nAmount to be paid: ₹" + $scope.getTotalAmount());
        localStorage.removeItem("cart");
        window.location.href = "index.php";
      };

      $scope.placeOnlineOrder = function () {
        if ($scope.cart.length === 0) {
          alert("Your cart is empty.");
          return;
        }

        alert("Redirecting to payment page...\nPayment Method: Online Payment\nAmount: ₹" + $scope.getTotalAmount());
        sessionStorage.setItem("amount", $scope.getTotalAmount());
        window.location.href = "payment.php";
      };
    });
  </script>
</body>
</html>
