<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Fast n Feast - Online Payment</title>
  <style>
    body {
      background-color: #121212;
      color: white;
      font-family: 'Segoe UI', sans-serif;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      min-height: 100vh;
      margin: 0;
      padding: 20px;
      animation: fadeIn 0.6s ease-in-out;
    }

    @keyframes fadeIn {
      from { opacity: 0; transform: scale(0.95); }
      to { opacity: 1; transform: scale(1); }
    }

    .payment-box {
      background-color: #1e1e1e;
      padding: 30px;
      border-radius: 16px;
      box-shadow: 0 0 25px rgba(255, 165, 0, 0.5);
      text-align: center;
      max-width: 400px;
      width: 100%;
    }

    h1 {
      color: #ffa726;
      margin-bottom: 20px;
    }

    .qr-code {
      width: 200px;
      height: 200px;
      margin-bottom: 20px;
      border-radius: 12px;
      box-shadow: 0 0 15px rgba(255, 255, 255, 0.2);
    }

    .amount {
      font-size: 24px;
      font-weight: bold;
      color: #4caf50;
      margin-bottom: 25px;
    }

    .confirm-btn {
      background-color: #4caf50;
      color: white;
      padding: 12px 25px;
      border: none;
      border-radius: 10px;
      font-size: 16px;
      cursor: pointer;
      transition: background-color 0.3s ease;
      width: 100%;
      margin-bottom: 15px;
    }

    .confirm-btn:hover {
      background-color: #43a047;
    }

    .home-link {
      display: block;
      text-decoration: none;
      color: #ffa726;
      font-size: 14px;
      margin-top: 10px;
    }

    .home-link:hover {
      text-decoration: underline;
    }

    .status {
      margin-top: 15px;
      font-size: 14px;
      color: #bbb;
    }

    .paid {
      color: #4caf50;
      font-weight: bold;
    }

    @media screen and (max-width: 500px) {
      .payment-box {
        padding: 20px;
      }

      .qr-code {
        width: 180px;
        height: 180px;
      }
    }
  </style>
</head>
<body>
  <div class="payment-box">
    <h1>Scan to Pay</h1>
    <img class="qr-code" id="qrImage" src="">
    <div class="amount">Total Amount: ₹<span id="amountDisplay">0</span></div>
    <button class="confirm-btn" onclick="confirmPayment()">✅ Confirm Payment</button>
    <a class="home-link" href="index.php">← Back to Home</a>
    <div class="status" id="paymentStatus">Waiting for confirmation...</div>
  </div>

  <script>
    // Load amount from sessionStorage
    const amount = sessionStorage.getItem("amount") || 0;
    document.getElementById("amountDisplay").innerText = amount;

    // Set QR code with UPI data
    const qr = document.getElementById("qrImage");
    qr.src = `https://api.qrserver.com/v1/create-qr-code/?data=upi://pay?pa=merchant@upi&pn=FastnFeast&am=${amount}&cu=INR&purpose=FastnFeastOrder`;

    function confirmPayment() {
      const cartItems = JSON.parse(localStorage.getItem("cart")) || [];
      const order = {
        items: cartItems,
        amount: amount,
        date: new Date().toLocaleString()
      };

      // Send order data to backend PHP
      fetch("save_payment.php", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(order)
      })
      .then(response => response.text())
      .then(data => {
        console.log(data);

        // Clear storage after order is placed
        localStorage.removeItem("cart");
        sessionStorage.removeItem("amount");

        // Show confirmation message
        document.getElementById("paymentStatus").innerHTML = "<span class='paid'>✅ Payment Confirmed! Thank you for your order.</span>";

        // Redirect to home after 3 seconds
        setTimeout(() => {
          window.location.href = "index.php";
        }, 3000);
      })
      .catch(error => {
        console.error("Error:", error);
        document.getElementById("paymentStatus").innerText = "❌ Payment failed. Try again.";
      });
    }
  </script>
</body>
</html>
