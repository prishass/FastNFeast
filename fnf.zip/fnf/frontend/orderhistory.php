<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Order History - Fast n Feast</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <style>
    body {
      margin: 0;
      font-family: 'Segoe UI', sans-serif;
      background: url('https://bit.ly/43XrhuN') no-repeat center center fixed;
      background-size: cover;
      background-color: rgba(18, 18, 18, 0.92);
      background-blend-mode: overlay;
      color: #f0f0f0;
    }

    .container {
      max-width: 900px;
      margin: 50px auto;
      background-color: #1f1f1f;
      border-radius: 12px;
      padding: 40px;
      box-shadow: 0 0 20px rgba(0,0,0,0.6);
    }

    h1 {
      text-align: center;
      color: #ffa726;
      margin-bottom: 40px;
    }

    table {
      width: 100%;
      border-collapse: collapse;
      background-color: #2a2a2a;
      border-radius: 10px;
      overflow: hidden;
    }

    th, td {
      padding: 14px 20px;
      text-align: left;
    }

    th {
      background-color: #3d3d3d;
      color: #ffcc80;
      text-transform: uppercase;
      font-size: 14px;
      border-bottom: 2px solid #444;
    }

    td {
      font-size: 15px;
      border-bottom: 1px solid #444;
    }

    tr:nth-child(even) {
      background-color: #252525;
    }

    tr:hover {
      background-color: #383838;
      transition: 0.3s ease;
    }

    .price {
      color: #66bb6a;
      font-weight: bold;
    }

    .payment {
      color: #81d4fa;
    }

    .back-btn {
      display: block;
      width: fit-content;
      margin: 40px auto 0;
      background-color: #ff5722;
      color: white;
      padding: 10px 20px;
      border-radius: 6px;
      text-decoration: none;
      font-size: 14px;
    }

    .back-btn:hover {
      background-color: #e64a19;
    }

    .icon {
      margin-right: 6px;
      color: #ffa726;
    }
  </style>
</head>
<body>
  <div class="container">
    <h1><i class="fas fa-history"></i> Your Order History</h1>

    <table>
      <thead>
        <tr>
          <th><i class="fas fa-utensils icon"></i>Item</th>
          <th><i class="fas fa-indian-rupee-sign icon"></i>Price</th>
          <th><i class="fas fa-calendar-alt icon"></i>Order Date</th>
          <th><i class="fas fa-credit-card icon"></i>Payment Method</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td>Paneer Tikka</td>
          <td class="price">₹200</td>
          <td>April 14, 2025</td>
          <td class="payment">Online Payment</td>
        </tr>
        <tr>
          <td>Spicy Mango Munch</td>
          <td class="price">₹149</td>
          <td>April 14, 2025</td>
          <td class="payment">Online Payment</td>
        </tr>
      </tbody>
    </table>

    <a class="back-btn" href="index.php"><i class="fas fa-arrow-left"></i> Back to Home</a>
  </div>
</body>
</html>
