<?php
session_start();
if (!isset($_SESSION['email'])) {
    header("Location: login.php"); // Redirect to login page if not logged in
    exit();
}
?>
<!DOCTYPE html>
<html ng-app="fastnFeastApp">
<head>
  <meta charset="UTF-8">
  <title>Fast n Feast - Dark Mode</title>

  <!-- AngularJS CDN -->
  <script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.8.2/angular.min.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  
  <style>
  body {
  font-family: 'Segoe UI', sans-serif;
  background: url('https://media.istockphoto.com/id/1191675284/photo/empty-real-wood-table-top-with-light-reflection-on-scene-at-restaurant-pub-or-bar-at-night.jpg?s=612x612&w=0&k=20&c=3EeHgv5AC2qdhBsumoayKqzeA_Lb1t-GtPoGkajyOwM=');
  background-size: cover;
  background-blend-mode: overlay;
  background-color: rgba(59, 53, 53, 0.9);
  color: #e0e0e0;
  margin: 0;
  padding: 0;
}

.social-icon {
  color: #888;
  text-decoration: none;
  font-size: 20px;
  transition: color 0.1s ease;
}

.social-icon:hover {
  color: #ffffff;

}

header {
  background-color: #1e1919;
  padding: 20px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  flex-wrap: wrap;
  border-bottom: 1px solid #333;
  gap: 10px;
}

.left-section {
  flex: 1;
}

.center-section {
  flex: 2;
  display: flex;
  align-items: center;
  gap: 15px;
  justify-content: center;
}

.right-section {
  flex: 1;
  display: flex;
  justify-content: flex-end;
  gap: 15px;
  align-items: center;
}

header h1 {
  color: #ff5722;
  margin: 0;
  font-size: 28px;
}

header p {
  font-size: 14px;
  color: #bbb;
  margin: 0;
}


    input[type="text"] {
      padding: 10px;
      font-size: 14px;
      border-radius: 5px;
      border: 1px solid #444;
      background-color: #2c2c2c;
      color: #fff;
      width: 220px;
      margin-left: 20px;
    }

    .cart-count {
      font-weight: bold;
      color: #ff9800;
      margin-left: 20px;
    }

    .menu, .specials {
      display: flex;
      flex-wrap: wrap;
      justify-content: center;
      gap: 20px;
      padding: 30px 20px;
    }

    .item {
      background-color: #1e1e1e;
      border-radius: 10px;
      box-shadow: 0 4px 15px rgba(0,0,0,0.3);
      padding: 15px;
      width: 240px;
      transition: transform 0.2s;
    }

    .item:hover {
      transform: scale(1.03);
    }

    .item img {
      width: 100%;
      height: 150px;
      object-fit: cover;
      border-radius: 8px;
    }

    .item h3 {
      margin: 10px 0 5px;
      font-size: 20px;
      color: #ff7043;
    }

    .item p {
      font-size: 14px;
      margin: 5px 0;
      color: #aaa;
    }

    .item strong {
      display: block;
      margin: 10px 0;
      font-size: 16px;
      color: #ffc107;
    }

    button {
      background-color: #ff5722;
      color: white;
      padding: 8px 14px;
      font-size: 14px;
      border: none;
      border-radius: 5px;
      cursor: pointer;
      transition: background 0.3s;
    }

    button:hover {
      background-color: #e64a19;
    }

    h2 {
      text-align: center;
      color: #ffa726;
      margin-top: 40px;
    }

    .logout-btn {
      background-color: #333;
      color: #fff;
      padding: 6px 12px;
      border-radius: 4px;
      text-decoration: none;
      font-size: 14px;
      border: 1px solid #555;
    }

  .logout-btn:hover {
      background-color: #555;
  }

  .cart-btn {
  cursor: pointer;
  transition: color 0.3s ease;
  }

.cart-btn:hover {
  color: #ff5722;
  text-decoration: underline;
}


.btn-order-history {
      display: inline-block;
      padding: 10px 20px;
      margin-top: 2px;
      background-color: #ffa726;
      color: white;
      text-decoration: none;
      border-radius: 5px;
      font-size: 16px;
    }

    .btn-order-history:hover {
      background-color: #e64a19;
    }
    
  </style>

<script>
  var app = angular.module('fastnFeastApp', []);

  app.controller('MenuController', function ($scope) {
    $scope.searchText = '';
    
    $scope.cart = [];
try {
  const storedCart = localStorage.getItem("cart");
  if (storedCart) {
    $scope.cart = JSON.parse(storedCart);
  }
} catch (err) {
  console.error("Error parsing cart from localStorage:", err);
}

    
$scope.getCartCount = function () {
  return $scope.cart?.length || 0;
};

    // Menu items definition
    $scope.menu = [
      {
        name: 'Paneer Tikka',
        description: 'Grilled paneer cubes with rich flavor',
        price: 200,
        image: 'https://images.unsplash.com/photo-1631452180519-c014fe946bc7?w=700&auto=format&fit=crop&q=60',
        special: false
      },
      {
        name: 'Spicy Mango Munch',
        description: 'Tangy mango-glazed potato bites with chili',
        price: 149,
        image: 'https://images.unsplash.com/photo-1601702538934-efffab67ab65?w=700&auto=format&fit=crop&q=60',
        special: true
      },
      {
        name: 'Cheesy Lava Burger',
        description: 'Juicy burger with molten cheese core',
        price: 199,
        image: 'https://media.istockphoto.com/id/2190253148/photo/pouring-cheddar-cheese-sauce-over-cheeseburger-with-bacon-and-fries-served-on-black-slate.jpg?s=612x612&w=0&k=20&c=BXRwXiYlujI6zfCqsusVR7e8JKJ0xf06pjBOCJoC4CE=',
        special: false
      },
      {
        name: 'Tandoori Momos',
        description: 'Smoky dumplings grilled with tandoori spices',
        price: 169,
        image: 'https://media.istockphoto.com/id/1356766002/photo/close-up-shot-of-spicy-vegetable-dimsums-momos-with-assorted-dips-chutney-in-a-serving-tray.jpg?s=612x612&w=0&k=20&c=ADauJksmSBABWEKKeCIJOZIKrH_qJVSFq59l6V6XNjo=',
        special: true
      },
      {
        name: 'Fiery Tango Tacos',
        description: 'Spicy chicken or paneer tossed in Mexican hot sauce.',
        price: 130.15,
        image: 'https://media.istockphoto.com/id/1204445926/photo/vegan-tacos-focus.jpg?s=612x612&w=0&k=20&c=CvwGBo6oUrCb_b0YVx5fDO9pnHCTjpvm4rHoeCKxONY=',
        special: true
      }
    ];

    // Function to add items to the cart
    $scope.addToCart = function (item) {
      $scope.cart.push(item); // Add item to cart
      localStorage.setItem("cart", JSON.stringify($scope.cart)); // Save cart to localStorage

      alert(item.name + " added to cart!");

      // Optional: Send to backend
      const customer_id = localStorage.getItem("customer_id") || "guest"; // Change as per your login setup
      const item_id = item.name; // or use a unique ID if available
      const quantity = 1;

      fetch("http://localhost:3000/add-to-cart", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          customer_id: customer_id,
          item_id: item_id,
          quantity: quantity
        })
      })
        .then(res => res.json())
        .then(data => {
          if (!data.success) {
            alert("Failed to save item to backend cart.");
          }
        })
        .catch(err => {
          console.error("Error:", err);
        });
    };

    // Make sure the cart count is correctly updated when page loads
    $scope.$watch('cart.length', function() {
      // This will trigger any change in the cart and update dynamically
    });

  });

  function goToCart() {
    window.location.href = "cart.html";
  };
</script>



</head>
<body ng-controller="MenuController">

  <header>
    <div class="left-section">
      <div class="title-group">
        <h1>🍽 Fast n Feast</h1>
        <p>Midnight munchies, sorted in minutes!</p>
      </div>
    </div>
  
    <div class="center-section">
      <input type="text" ng-model="searchText" placeholder="Search dishes...">
      <a href="orderhistory.php" class="btn-order-history">Order History</a>
    </div>
  
    <div class="right-section">
    <span class="cart-count cart-btn" onclick="window.location.href='cart.php'">🛒 View Cart</span>
      <a href="logout.php" class="logout-btn">Logout</a>
    </div>
  </header>
  
  
  

  <section>
    <h2 style="color: wheat;">⭐ Special of the Day</h2>
    <div class="specials">
      <div class="item" ng-repeat="item in menu | filter:searchText | filter:{special:true}">
        <img ng-src="{{item.image}}" alt="{{item.name}}">
        <h3>{{item.name}}</h3>
        <p>{{item.description}}</p>
        <strong>₹{{item.price}}</strong>
        <button ng-click="addToCart(item)">Add to Cart</button>
      </div>
    </div>
  </section>

  <section>
    <h2 style="color: wheat;">📜 Full Menu</h2>
    <div class="menu">
      <div class="item" ng-repeat="item in menu | filter:searchText | filter:{special:false}">
        <img ng-src="{{item.image}}" alt="{{item.name}}">
        <h3>{{item.name}}</h3>
        <p>{{item.description}}</p>
        <strong>₹{{item.price}}</strong>
        <button ng-click="addToCart(item)">Add to Cart</button>
      </div>
    </div>
  </section>
  
  <footer style="background: #1e1919; color: #ccc; padding: 20px 10px; font-family: 'Segoe UI', sans-serif; font-size: 14px; text-align: center;">
    <div style="margin-bottom: 10px;">
      <span style="margin: 0 10px;">📍 Mumbai</span>
      <span style="margin: 0 10px;">📧 <a href="mailto:fastnfeast@gmail.com" style="color: #ffb74d; text-decoration: none;">fastnfeast@gmail.com</a></span>
      <span style="margin: 0 10px;">📞 +91 98765 43210</span>
    </div>
    <div style="display: flex; justify-content: center; gap: 40px; margin-bottom: 8px;">
      <div style="text-align: center;">
        <a href="#" style="color: #888; text-decoration: none;">Instagram</a><br>
        <a href="#" style="color: #888; text-decoration: none; font-size: 20px;">
          <i class="fab fa-instagram social-icon"></i>
        </a>
      </div>
      <div style="text-align: center;">
        <a href="#" style="color: #888; text-decoration: none;">Facebook</a><br>
        <a href="#" style="color: #888; text-decoration: none; font-size: 20px;">
          <i class="fab fa-facebook-f social-icon"></i>
        </a>
      </div>
      <div style="text-align: center;">
        <a href="#" style="color: #888; text-decoration: none;">Twitter</a><br>
        <a href="#" style="color: #888; text-decoration: none; font-size: 20px;">
          <i class="fab fa-twitter social-icon"></i>
        </a>
      </div>
    </div>
    
      
      <div style=" text-align: center;">&copy; 2025 Fast n Feast — Crafted with ❤️</div>
  </footer>
      
</body>
</html>