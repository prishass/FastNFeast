<?php
session_start();
$host = "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbName = "fastnfeast";

$conn = new mysqli($host, $dbUsername, $dbPassword, $dbName);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle form only when submitted
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $email = $_POST['email'];
    $password = $_POST['password'];
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

    $checkQuery = "SELECT * FROM users WHERE email = ?";
    $stmt = $conn->prepare($checkQuery);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // Login flow
        $row = $result->fetch_assoc();
        if (password_verify($password, $row['password'])) {
            $_SESSION['email'] = $email;
            header("Location: index.php");
            exit();
        } else {
            $error = "Incorrect password!";
        }
    } else {
        // Register new user
        $insertQuery = "INSERT INTO users (email, password) VALUES (?, ?)";
        $stmt = $conn->prepare($insertQuery);
        $stmt->bind_param("ss", $email, $hashedPassword);
        if ($stmt->execute()) {
            $_SESSION['email'] = $email;
            header("Location: index.php");
            exit();
        } else {
            $error = "Registration failed. Try again.";
        }
    }

    $conn->close();
}
?>




<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Login - Fast n Feast</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <style>
    body {
      margin: 0;
      padding: 0;
      background: url('https://images.unsplash.com/photo-1546069901-ba9599a7e63c') no-repeat center center/cover;
      height: 100vh;
      font-family: 'Segoe UI', sans-serif;
      display: flex;
      justify-content: center;
      align-items: center;
      position: relative;
      color: #f0f0f0;
    }

    body::before {
      content: "";
      position: absolute;
      top: 0; left: 0; right: 0; bottom: 0;
      background-color: rgba(0, 0, 0, 0.75);
      z-index: 1;
    }

    .login-container {
      position: relative;
      z-index: 2;
      background-color: #1f1f1f;
      padding: 40px 30px;
      border-radius: 16px;
      box-shadow: 0 0 25px rgba(0, 0, 0, 0.7);
      width: 340px;
      animation: fadeIn 1s ease;
    }

    @keyframes fadeIn {
      from { opacity: 0; transform: translateY(20px); }
      to { opacity: 1; transform: translateY(0); }
    }

    .login-container h2 {
      text-align: center;
      color: #ffa726;
      margin-bottom: 20px;
    }

    .logo {
      display: block;
      margin: 0 auto 10px;
      width: 70px;
      height: 70px;
      border-radius: 50%;
      box-shadow: 0 0 10px #ff7043;
    }

    input {
      width: 100%;
      padding: 12px;
      margin: 12px 0 20px;
      border: 1px solid #444;
      border-radius: 6px;
      background-color: #2c2c2c;
      color: #fff;
      font-size: 15px;
      transition: border 0.3s;
    }

    input:focus {
      outline: none;
      border: 1px solid #ffa726;
      box-shadow: 0 0 8px rgba(255, 167, 38, 0.6);
    }

    button {
      width: 100%;
      background: linear-gradient(135deg, #ff5722, #ff7043);
      color: white;
      padding: 12px;
      border: none;
      border-radius: 8px;
      font-size: 16px;
      font-weight: bold;
      cursor: pointer;
      transition: background 0.4s, transform 0.2s;
    }

    button:hover {
      background: linear-gradient(135deg, #e64a19, #ff5722);
      transform: scale(1.02);
    }

    .note {
      text-align: center;
      font-size: 12px;
      color: #ccc;
      margin-top: 15px;
    }

    @media (max-width: 400px) {
      .login-container {
        width: 90%;
        padding: 30px 20px;
      }
    }
  </style>
</head>
<body>
  <div class="login-container">
    <img src="https://cdn-icons-png.flaticon.com/512/3075/3075977.png" class="logo" alt="Fast n Feast Logo">
    <h2><i class="fas fa-sign-in-alt"></i> Welcome Back!</h2>
    <?php if (!empty($error)): ?>
    <p style="color: #ff6b6b; text-align: center;"><?php echo $error; ?></p>
  <?php endif; ?>
    <form method="POST" action="login.php">
  <input type="text" name="email" placeholder="Email" required>
  <input type="password" name="password" placeholder="Password" required>
  <button type="submit">Login / Register</button>
</form>

    <div class="note">Have Your Happy Meal Here!</div>
  </div>
</body>
</html>