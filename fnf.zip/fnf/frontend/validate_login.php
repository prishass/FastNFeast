<?php
// Database connection
$conn = new mysqli("localhost", "root", "", "fastnfeast_db"); // change DB name if different

if ($conn->connect_error) {
  die(json_encode(['status' => 'error', 'message' => 'Connection failed']));
}

$data = json_decode(file_get_contents("php://input"), true);
$email = $data['email'];
$password = $data['password'];

// Query (make sure your table is named 'users' and has 'email' and 'password' fields)
$sql = "SELECT * FROM users WHERE email='$email' AND password='$password'";
$result = $conn->query($sql);

if ($result && $result->num_rows > 0) {
  echo json_encode(['status' => 'success']);
} else {
  echo json_encode(['status' => 'fail']);
}

$conn->close();
?>
